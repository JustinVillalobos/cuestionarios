@extends('./layouts.admin')
@section('content')  
<div class="row" style="margin-top:25px;">
    <div class="col-sm-12">
        <div class="" style="padding-left:5px;">
            <ol class="breadcrumb">

                <li class="breadcrumb-item"><a href='' class="text-info"> <h5><i class="fa fa-book" aria-hidden="true"></i>Cuestionario</h5></a></li>
                <li class="breadcrumb-item active" aria-current="page">Agregar Cuestionario</li>
            </ol>
        </div>
    </div>
</div>
<div class="row" style="margin-top:15px;">
    
    

   
</div>
 
<script src="{{ URL::asset('js/pais/add.js'); }}"></script>     
@stop